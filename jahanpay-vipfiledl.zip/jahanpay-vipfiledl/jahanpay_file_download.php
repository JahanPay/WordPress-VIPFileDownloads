<?php
/*
Plugin Name: JahanPAy VIP & File Download
Plugin URI: http://jahanpay.me
Description: افزونه فروشگاه فایل دانلود در ازای پرداخت وجوه و اشتراک ویژه
Version: 1.2
Author: ویرایش توسط jahanpay.me
Author URI: http://www.jahanpay.me
*/

include_once('jahanpay_func.php');